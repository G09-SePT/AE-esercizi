public class IntControlLine
{

	private int value;

	public IntControlLine()
	{
	}

	public void setValue(int value)
	{
		this.value = value;
	}

	public int getValue()
	{
		return value;
	}
}
