class OutRangeNumberException extends Exception
{

}
