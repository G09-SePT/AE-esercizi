public enum ParamType
{
	BYTE, CONST, VARNUM, LABEL, OFFSET, INDEX;
}
