
/****
 *
 *File used to capture an exception.
 *
 * @author
 *   Simone Alciati (e-mail: alciati@edu-al.unipmn.it),
 *   U.P.O.
 *   Alessandria Italy
 ****/

class RegisterValueException extends Exception
{

}
