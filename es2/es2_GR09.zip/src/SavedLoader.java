
public class SavedLoader implements Mic1Constants
{

//  //BufferedInputStream in = null; //Tipo creato dall'autore...
//  String filename;
//  String msg = null;
//  byte program[];
//  boolean eof;
//
//
//  public SavedLoader(String filename) throws IOException {
//    this.filename = filename;
//    eof = false;
//    program = new byte[MEM_MAX];
//    in = new BufferedInputStream(new FileInputStream(filename));
//    if (validateFile()) 
//      while (!eof) readBlock();
//  }
//  
//  public String isValid() {
//    return msg;
//  }
//  
// 
//
//  }
//  
//  
//  public String isValid() {
//    return null;
//  }
//  
//  public byte[] getSavedProgram() {
//    return null; 
//  /*Devi restituire tre cose (o piu'):
//  	non farai una getSavedProgram, ma: 
//  	-lo stato dei registri : getRegister
//	-lo stato della memoria (programma e stack) :getMemory
//	-e, in genrale, tutte le cose che vai a inizializzare nella mic1sim
//  */
//	/*}

}
